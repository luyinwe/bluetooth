# THIS FILE IS GENERATED FROM TRAITS SETUP.PY
version = '4.6.0'
full_version = '4.6.0'
git_revision = 'd1d0776'
is_released = True

if not is_released:
    version = full_version
