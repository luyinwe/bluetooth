#required by simple_test_case.py so it can do an import
