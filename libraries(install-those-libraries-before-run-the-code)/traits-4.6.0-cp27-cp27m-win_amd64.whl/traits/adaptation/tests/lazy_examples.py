""" Examples for lazy adapter factories.

This module should be only imported when the adaptation takes place.
"""


class IBar(object):
    pass

class IBarToIFoo(object):
    pass

class IFoo(object):
    pass

#### EOF ######################################################################
